package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.VO;

/**
 * Servlet implementation class InjectionInsertServlet
 */
@WebServlet("/InjectionInsert")
public class InjectionInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InjectionInsertServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("injection_insert.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		VO vo = new VO();
		
		vo.setP_seno(Integer.valueOf(request.getParameter("p_seno")));
		vo.setP_no(request.getParameter("p_no"));
		vo.setI_code(request.getParameter("i_code"));
		vo.setP_date(request.getParameter("p_date"));
		
		boolean result = new DAO().insertInjection(vo)>0;
		
		request.setAttribute("result", result);
		RequestDispatcher rd = request.getRequestDispatcher("injection_insert.jsp");
		rd.forward(request, response);
		
	}

}
