package servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.DAO;
import model.VO;

/**
 * Servlet implementation class CustListServlet
 */
@WebServlet("/CustList")
public class CustListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<VO> list = new DAO().getCustList();
		
		String temp = null;
		
		for(VO vo : list) {
			vo.setP_gender(vo.getP_gender().equals("M") ? "남" : "여");
			
			temp = vo.getP_city();
			if(temp.equals("10")) {
				vo.setP_city("서울");
			}else if(temp.equals("20")) {
				vo.setP_city("경기");
			}else if(temp.equals("30")) {
				vo.setP_city("강원");
			}else if(temp.equals("40")) {
				vo.setP_city("대구");
			}
			
			LocalDate local = LocalDate.now();
			int currentYear = local.getYear();
			
			temp = vo.getP_birth();
			String year = temp.substring(0, 4);
			String month = temp.substring(4, 6);
			String day = temp.substring(6, 8);
			String age = String.valueOf(currentYear-Integer.valueOf(year));
			vo.setP_birth(year + "년" + month + "월" + day + "일 (" + age + ")");
		}
		
		request.setAttribute("list", list);
		
		RequestDispatcher rd = request.getRequestDispatcher("/cust_list.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
