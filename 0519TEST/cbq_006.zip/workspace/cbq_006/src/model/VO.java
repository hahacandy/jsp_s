package model;

public class VO {
	private String p_no;
	private String p_name;
	private String p_birth;
	private String p_gender;
	private String p_tel1;
	private String p_tel2;
	private String p_tel3;
	private String p_city;
	
	private String i_code;
	private String i_name;
	private String i_age;

	private int p_seno;
	private String p_senoS;
	private String p_date;
	
	private int cnt;
	
	public String getP_no() {
		return p_no;
	}
	public void setP_no(String p_no) {
		this.p_no = p_no;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_birth() {
		return p_birth;
	}
	public void setP_birth(String p_birth) {
		this.p_birth = p_birth;
	}
	public String getP_gender() {
		return p_gender;
	}
	public void setP_gender(String p_gender) {
		this.p_gender = p_gender;
	}
	public String getP_tel1() {
		return p_tel1;
	}
	public void setP_tel1(String p_tel1) {
		this.p_tel1 = p_tel1;
	}
	public String getP_tel2() {
		return p_tel2;
	}
	public void setP_tel2(String p_tel2) {
		this.p_tel2 = p_tel2;
	}
	public String getP_tel3() {
		return p_tel3;
	}
	public void setP_tel3(String p_tel3) {
		this.p_tel3 = p_tel3;
	}
	public String getP_city() {
		return p_city;
	}
	public void setP_city(String p_city) {
		this.p_city = p_city;
	}
	public String getI_code() {
		return i_code;
	}
	public void setI_code(String i_code) {
		this.i_code = i_code;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public String getI_age() {
		return i_age;
	}
	public void setI_age(String i_age) {
		this.i_age = i_age;
	}
	public int getP_seno() {
		return p_seno;
	}
	public void setP_seno(int p_seno) {
		this.p_seno = p_seno;
	}
	public String getP_date() {
		return p_date;
	}
	public void setP_date(String p_date) {
		this.p_date = p_date;
	}
	public String getP_senoS() {
		return p_senoS;
	}
	public void setP_senoS(String p_senoS) {
		this.p_senoS = p_senoS;
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	
	

	
	
}
