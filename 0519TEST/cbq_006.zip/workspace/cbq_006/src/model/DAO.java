package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAO {

	public List<VO> getCountByInjection(){
		String query = "SELECT a.i_code, b.i_name, COUNT(*) cnt " + 
				"FROM tbl_order_201004 a, tbl_injection_201004 b " + 
				"WHERE a.i_code=b.i_code " + 
				"GROUP BY a.i_code, b.i_name " + 
				"ORDER BY a.i_code" + 
				"";
		return select(query);
	}
	
	public List<VO> getInjectList(){
		String query = "SELECT a.p_seno, a.p_no, b.p_name, c.i_code, c.i_name, a.p_date " + 
				"FROM tbl_order_201004 a, tbl_cust_201004 b, tbl_injection_201004 c " + 
				"WHERE a.p_no=b.p_no AND a.i_code=c.i_code " + 
				"ORDER BY a.p_no, c.i_code";
		return select(query);
	}
	
	public int insertInjection(VO vo) {
		String query = "INSERT INTO tbl_order_201004 VALUES("+vo.getP_seno()+", '"+vo.getP_no()+"', '"+vo.getI_code()+"', TO_DATE('"+vo.getP_date()+"', 'YYYY-MM-DD'))";
		System.out.println(query);
		return update(query);
	}
	
	public List<VO> getCustList(){
		String query = "SELECT * FROM tbl_cust_201004 ORDER BY p_no";
		return select(query);
	}
	
	public List<VO> select(String query){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<VO> list = new ArrayList<VO>();
		VO vo = null;
		
		try {
			
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				vo = new VO();
				try {
					vo.setP_no(rs.getString("p_no"));
				} catch (Exception e) {}
				try {
					vo.setP_name(rs.getString("p_name"));
				} catch (Exception e) {}
				try {
					vo.setP_birth(rs.getString("p_birth"));
				} catch (Exception e) {}
				try {
					vo.setP_gender(rs.getString("p_gender"));
				} catch (Exception e) {}
				try {
					vo.setP_tel1(rs.getString("p_tel1"));
				} catch (Exception e) {}
				try {
					vo.setP_tel2(rs.getString("p_tel2"));
				} catch (Exception e) {}
				try {
					vo.setP_tel3(rs.getString("p_tel3"));
				} catch (Exception e) {}
				try {
					vo.setP_city(rs.getString("p_city"));
				} catch (Exception e) {}
				
				try {
					vo.setI_code(rs.getString("i_code"));
				} catch (Exception e) {}
				try {
					vo.setI_name(rs.getString("i_name"));
				} catch (Exception e) {}
				try {
					vo.setI_age(rs.getString("i_age"));
				} catch (Exception e) {}
				
				try {
					vo.setP_seno(rs.getInt("p_seno"));
				} catch (Exception e) {}
				try {
					vo.setP_date(rs.getString("p_date"));
				} catch (Exception e) {}
				
				try {
					vo.setCnt(rs.getInt("cnt"));
				} catch (Exception e) {}
				
				list.add(vo);

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDB(rs, pstmt, conn);
		}
		return list;
	}
	
	public int update(String query) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int row = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(query);
			row = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDB(null, pstmt, conn);
		}
		return row;
	}
	
	
	public void closeDB(ResultSet rs, PreparedStatement pstmt, Connection conn) {
		if(rs!=null)
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if(pstmt!=null)
			try {
				pstmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if(conn!=null)
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "system", "1234");
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
